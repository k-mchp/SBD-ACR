/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _APP_H
#define _APP_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "mcc_generated_files/system/system.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END
    
#define SAMPLES 64          // Number of samples per sine wave cycle
#define CYCLES 16           // Number of cycles to collect
//#define NUM_ADC_SAMPLES 400
#define NUM_ADC_SAMPLES (SAMPLES*CYCLES)
#define BANDWIDTH 4000UL
#define TIMER_CLK 100000000UL
#define SAMPLE_RATE (BANDWIDTH*SAMPLES)
#define PERIOD_VAL ((TIMER_CLK/SAMPLE_RATE) - 1)
#define MASK_32_BIT_LOW 0x0000FFFFUL
#define MASK_32_BIT_HIGH 0xFFFF0000UL

#define SINE_WAVE_AMPLITUDE_VOLTS		(0.150)     //Amplitude Volts
#define SINE_DC_OFFSET_VOLTS			(3.3/2)     //Offset Volts
#define DAC_VOLTAGE_REF					(3.3)     //DAC Voltage Reference
#define SINE_AMPLITUDE                   (uint16_t)((SINE_WAVE_AMPLITUDE_VOLTS/DAC_VOLTAGE_REF)*0xFFF)    // Sine wave amplitude
#define SINE_DC_OFFSET                   (uint16_t)((SINE_DC_OFFSET_VOLTS/DAC_VOLTAGE_REF)*0xFFF)         // Sine wave DC offset
#define M_2PI                            (2 * M_PI)     // 2*PI
    
// Sample parameters for impedance calculations
// ZC = Zero Cross, SLO = Sample LO, SHI = Sample HI
#define INJ_ZC      0
#define INJ_SLO     4
#define INJ_SHI     35
#define IMP_ZC      0
#define RE_SLO      4
#define RE_SHI      35
#define IMG_SLO     20
#define IMG_SHI     51

bool ACR_Compute(uint8_t port);
void ACR_CollectData(uint8_t battery);
void ACR_ProcessData(void);
void sine_wave_table_init(void);

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************
typedef int16_t SENSOR_DATA_T;

// *****************************************************************************
/* Application states

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/

typedef enum
{
    /* Application's state machine's initial state. */
    APP_STATE_INIT=0,
            
            /* these states are for the program in data logging mode */
    APP_STATE_STREAM_WAIT_BUTTON_PRESS,
    APP_STATE_STREAM_START,
    APP_STATE_STREAM_SAMPLE,
    APP_STATE_STREAM_STOP,        
        
    /* these states are for the program in normal (classification) mode */
    APP_STATE_NORMAL_START,
    APP_STATE_NORMAL_WAIT,
    APP_STATE_NORMAL_PRINT_CLASSIFICATION
} APP_STATES;


// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    /* The application's current state */
    APP_STATES state;

    /* TODO: Define any additional data used by the application. */

} APP_DATA;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Routines
// *****************************************************************************
// *****************************************************************************
/* These routines are called by drivers when certain events occur.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Summary:
     MPLAB Harmony application initialization routine.

  Description:
    This function initializes the Harmony application.  It places the
    application in its initial state and prepares it to run so that its
    APP_Tasks function can be called.

  Precondition:
    All other system initialization routines should be called before calling
    this routine (in "SYS_Initialize").

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Initialize();
    </code>

  Remarks:
    This routine must be called from the SYS_Initialize function.
*/

void APP_Initialize ( void );


/*******************************************************************************
  Function:
    void APP_Tasks ( void )

  Summary:
    MPLAB Harmony Demo application tasks function

  Description:
    This routine is the Harmony Demo application's tasks function.  It
    defines the application's state machine and core logic.

  Precondition:
    The system and application initialization ("SYS_Initialize") should be
    called before calling this.

  Parameters:
    None.

  Returns:
    None.

  Example:
    <code>
    APP_Tasks();
    </code>

  Remarks:
    This routine must be called from SYS_Tasks() routine.
 */

void APP_Tasks( void );

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* _APP_H */

/*******************************************************************************
 End of File
 */

