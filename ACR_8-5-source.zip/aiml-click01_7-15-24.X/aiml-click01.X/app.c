/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdio.h>
#include <string.h>
#include "app.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/timer/delay.h"
#include "mcc_generated_files/timer/sccp2.h"
#include "mcc_generated_files/cmp/cmp2.h"
#include "mcc_generated_files/adc/adc1.h"

//KPL #include "kb.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.

    Application strings and buffers are be defined outside this structure.
*/
#define REMOVE_AIML_STUB_FUNCTIONS 1
#define USE_SPI_ADC                0
#define USE_IO1_LIGHT_SENSOR       1

APP_DATA appData;

uint32_t PeriodReg;

volatile uint16_t adc_sample[NUM_ADC_SAMPLES];
volatile bool adc_result_ready = false;
int sample_count;

/* this data is derived from the model.json file and provides name mappings 
 * for each of the classifications */
const char* classMap[] = {
    "Unknown",
    "Ambient",
    "Sensor Covered",
    "Torch Blink",
    "Torch Full",
    "Torch Mid",
};


int32_t inj_offset = 0;
int32_t battv_offset = 0;
int32_t inj_accum = 0;
int32_t REaccum = 0;
int32_t IMGaccum = 0;
uint16_t sine_wave[SAMPLES];        // Buffer to store the sine wave samples 
uint16_t sample_cnt = 0;
uint16_t cycle_cnt = 0;
bool pass = false;
bool collect_complete = false;
bool next_step = false;

typedef struct{
    uint16_t INJ[CYCLES][SAMPLES];
    uint16_t BATTV[CYCLES][SAMPLES];
} ACR_Data;

ACR_Data ADC_Buff;


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************
/* Get the light adc value from the light click in SPI mode */
uint16_t get_sample_spi_mode(void)
{
//    uint8_t data_buffer[2];
    uint16_t sample=0;
    /* run the SPI transaction */
    
    /* KPL
    CS1_SetLow();
    LIGHT_CLICK_SPI_BufferRead((void *)&data_buffer, sizeof(data_buffer));
    CS1_SetHigh();
    // Get the 12 bit sample from the data buffer to return to caller
    sample = ((data_buffer[0] & 0x1F) << 8) | (data_buffer[1]);
    // Shift the sample to right-justify it
    sample = sample >> 1;
     
     KPL */
    
    return(sample);
}

#if (REMOVE_AIML_STUB_FUNCTIONS == 0)
/* These stub functions implement the minimum aiml library functions 
 * required to get a successful compile. They are present in order to allow
 * the code to function as a data collector before the aiml knowledge pack
 * has been created. Once the library has been built then they can be
 * commented out or removed. */

void kb_model_init()
{

}

int32_t kb_reset_model(int32_t model_index)
{
    return 0;
}

int32_t kb_run_model(int16_t* pSample, int32_t nsensors, int32_t model_index)
{
    /* default to returning unknown classification */
    return 0;
}
#endif 

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */


void APP_Initialize ( void )
{
    RED_RB4_SetHigh();
    GREEN_RB5_SetHigh();
    
    PeriodReg = PERIOD_VAL;
    CCP2PRL = (uint16_t)(PeriodReg & MASK_32_BIT_LOW);
    CCP2PRH = (uint16_t)((PeriodReg & MASK_32_BIT_HIGH) >> 16);
        
    // Set the period for the timer to set the SPS rate
    
    
    ACR_Compute(1);
    //ACR_Compute(2);
  
 /*KPL
    
    // Place the App state machine in its initial state.
    appData.state = APP_STATE_INIT;
    LED_SetHigh();
    //SWITCH_InputEnable();
    // Open the SPI interface driver
#if USE_SPI_ADC    
    LIGHT_CLICK_SPI_Open(HOST_CONFIG);
#endif     
#if USE_IO1_LIGHT_SENSOR
    ADC0_SetWindowChannel(ADC0_IO_PD5);
#else
    ADC0_SetWindowChannel(ADC0_IO_PD4);
#endif
    
    kb_model_init();
    kb_reset_model(0);
    
 KPL */
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */
uint8_t output_buffer[4];
void APP_Tasks ( void )
{ 
    RED_RB4_Toggle();
    DELAY_milliseconds(200);
    //GREEN_RB5_Toggle();
   
 /* KPL
    
    int sample_index;
    int kb_rval;
    uint16_t sample;
    SENSOR_DATA_T sdSample;
    uint8_t *byte_p = (uint8_t *)&sample;
    
    // Check the application's current state.
    switch ( appData.state )
    {
        // Application's initial state.
        case APP_STATE_INIT:
            printf("init\r\n");
            
#if USE_SPI_ADC
            // configure the TCA0 overflow interrupt handler to indicate when 
            // to capture a sample from the MCP3201 on the click borrd
             
            TCA0_OverflowCallbackRegister(tca0_overflow_callback);
#else            
            // Configure the ADC1 conversion complete interrupt handler to indicate
            // when a sample has been captured from the ADC
             
            ADC0_RegisterResrdyCallback(adc0_res_ready_callback);
            TCA0_Start();
#endif            
            // Insert the data visualizer framing bytes into the data buffer
            output_buffer[0] = 0x03;
            output_buffer[3] = 0xFC;          
        
            // depending on the button at startup either go into logging mode
            // or into analysis mode (analysis mode indicated by pulsing LED)
            if (SWITCH_GetValue() == 0)
            {
                appData.state = APP_STATE_STREAM_WAIT_BUTTON_PRESS;
            }
            else
            {
                appData.state = APP_STATE_NORMAL_START;
            }

            break;
        
        // these states are associated with collecting data to create the model
        
        case APP_STATE_STREAM_WAIT_BUTTON_PRESS:
            if (SWITCH_GetValue() == 0) 
            {
                printf("press\r\n");
                appData.state = APP_STATE_STREAM_START;
            }
            break;

        case APP_STATE_STREAM_START:
            LED_SetLow();
            
            // perform debounce on the switch
            if (SWITCH_GetValue() != 0)
            {
                printf("start\r\n");
                // button has been released so begin sampling
#if USE_SPI_ADC
                // SPI mode uses TCA0 to trigger the ADC capture from the MCP3201
                adc_result_ready = false;
                TCA0_Start();
#else
                // Enable the ADC to capture samples
                ADC0_Enable();
#endif                 
                appData.state = APP_STATE_STREAM_SAMPLE;
            }
            break;
            
        case APP_STATE_STREAM_SAMPLE:
            // if new ADC data is available output it via stdout
            if (adc_result_ready == true)
            {
                adc_result_ready = false;
                // output the result
#if USE_SPI_ADC
                sample = get_sample_spi_mode();
#else
                sample = ADC0_GetConversionResult();
#endif                 
                //memcpy(&output_buffer[1], &sample, 2);
                output_buffer[1] = byte_p[0];
                output_buffer[2] = byte_p[1];
                fwrite(output_buffer, 1, 4, stdout);
            }
            
            // test the button to check whether to continue sampling
            if (SWITCH_GetValue() == 0) 
            {
                printf("stop\r\n");
                // switch has been release so stop sampling
                LED_SetHigh();
                //ADC1_Disable();
#if USE_SPI_ADC
                TCA0_Stop();
                adc_result_ready = false;
#else
                ADC0_Disable();
#endif 
                appData.state = APP_STATE_STREAM_STOP;
            }

            break;      
            
        case APP_STATE_STREAM_STOP:
            // debounce the button press
            if (SWITCH_GetValue() != 0)
            {
                printf("wait\r\n");
                appData.state = APP_STATE_STREAM_WAIT_BUTTON_PRESS;
            }
            break;
            
        // these states are associated with running the model 
        // Here the sampling algorithm records NUM_ADC_SAMPLES
        // and then processes them via the knowledge pack   
            
        case APP_STATE_NORMAL_START:
            sample_count = 0;
#if USE_SPI_ADC
                adc_result_ready = false;
                TCA0_Start();
#else
                ADC0_Enable();
#endif                 
            appData.state = APP_STATE_NORMAL_WAIT;
            break;

        case APP_STATE_NORMAL_WAIT:
            if (adc_result_ready == true)
            {
                adc_result_ready = false;             
#if USE_SPI_ADC
                adc_sample[sample_count++]  = get_sample_spi_mode();
#else
                adc_sample[sample_count++]  = ADC0_GetConversionResult();
#endif                 
                
                if (sample_count >= NUM_ADC_SAMPLES)
                {
                    appData.state = APP_STATE_NORMAL_PRINT_CLASSIFICATION;
                }
            }
            break;
            
        case APP_STATE_NORMAL_PRINT_CLASSIFICATION:
            // process the block of data
            LED_SetLow();
            for(sample_index = 0; sample_index < NUM_ADC_SAMPLES; sample_index++)
            {
                DEBUG_PIN_Toggle();
                sdSample = (SENSOR_DATA_T) adc_sample[sample_index];
                kb_rval = kb_run_model(&sdSample, 1, 0);
                if (kb_rval >= 0)
                {
                    printf("%s\r\n", classMap[kb_rval]);
                    kb_reset_model(0);
                }
            }
            
            LED_SetHigh();
            sample_count = 0;
            kb_flush_model_buffer(0);
            appData.state = APP_STATE_NORMAL_WAIT;
            break;
            
        // The default state should never be executed.
            
            
                    
        default:
            break;
    }
   
 KPL */    
    
}

void sine_wave_table_init(void)
{
  for(uint16_t i = 0; i < SAMPLES; i++)
  {
    sine_wave[i] = SINE_DC_OFFSET + SINE_AMPLITUDE * sin(i * M_2PI / SAMPLES);
  }
  
}

void ACR_ProcessData(void)
{
    // ToDo Add Battery dV/dT routine 
    
    // Injection current offset
    sample_cnt = 0;
    cycle_cnt = 0;
    inj_offset = 0;
    next_step = false;
    
    while(next_step == false)
    {
        inj_offset = inj_offset + ADC_Buff.INJ[cycle_cnt][sample_cnt];

        sample_cnt++;
        if (sample_cnt == SAMPLES)
        {
            sample_cnt = 0;
            cycle_cnt++;
        }
        if (cycle_cnt == CYCLES)
        {
            inj_offset = inj_offset / (SAMPLES * CYCLES);
            next_step = true;
        }
    }
    
    // Injection current calculation
    sample_cnt = 0;
    cycle_cnt = 0;
    inj_accum = 0;
    next_step = false;
    
    while(next_step == false)
    {
        if ((sample_cnt >= INJ_SLO) || (sample_cnt <= INJ_SHI))
            inj_accum = inj_accum + (int32_t)(ADC_Buff.INJ[cycle_cnt][sample_cnt]) - inj_offset;

        if ((sample_cnt < INJ_SLO) || (sample_cnt > INJ_SHI))
            inj_accum = inj_accum - (int32_t)(ADC_Buff.INJ[cycle_cnt][sample_cnt]) + inj_offset;

        sample_cnt++;
        if (sample_cnt == SAMPLES)
        {
            sample_cnt = 0;
            cycle_cnt++;
        }
        if (cycle_cnt == CYCLES)
        {
            next_step = true;
        }
    }

    // Battery voltage offset
    sample_cnt = 0;
    cycle_cnt = 0;
    battv_offset = 0;
    next_step = false;
    
    while(next_step == false)
    {
        battv_offset = battv_offset + ADC_Buff.BATTV[cycle_cnt][sample_cnt];

        sample_cnt++;
        if (sample_cnt == SAMPLES)
        {
            sample_cnt = 0;
            cycle_cnt++;
        }
        if (cycle_cnt == CYCLES)
        {
            battv_offset = battv_offset / (SAMPLES * CYCLES);
            next_step = true;
        }
    }
    
    // Real Battery impedance calculation
    sample_cnt = 0;
    cycle_cnt = 0;
    REaccum = 0;
    next_step = false;
    
    while(next_step == false)
    {
        if ((sample_cnt >= RE_SLO) || (sample_cnt <= RE_SHI))
            REaccum = REaccum + (int32_t)(ADC_Buff.BATTV[cycle_cnt][sample_cnt]) - inj_offset;

        if ((sample_cnt < RE_SLO) || (sample_cnt > RE_SHI))
            REaccum = REaccum - (int32_t)(ADC_Buff.BATTV[cycle_cnt][sample_cnt]) + inj_offset;

        sample_cnt++;
        if (sample_cnt == SAMPLES)
        {
            sample_cnt = 0;
            cycle_cnt++;
        }
        if (cycle_cnt == CYCLES)
        {
            next_step = true;
        }
    }
    
    // Imaginary Battery impedance calculation
    sample_cnt = 0;
    cycle_cnt = 0;
    IMGaccum = 0;
    next_step = false;
    
    while(next_step == false)
    {
        if ((sample_cnt >= IMG_SLO) || (sample_cnt <= IMG_SHI))
            IMGaccum = IMGaccum + (int32_t)(ADC_Buff.BATTV[cycle_cnt][sample_cnt]) - inj_offset;

        if ((sample_cnt < IMG_SLO) || (sample_cnt > IMG_SHI))
            IMGaccum = IMGaccum - (int32_t)(ADC_Buff.BATTV[cycle_cnt][sample_cnt]) + inj_offset;

        sample_cnt++;
        if (sample_cnt == SAMPLES)
        {
            sample_cnt = 0;
            cycle_cnt++;
        }
        if (cycle_cnt == CYCLES)
        {
            next_step = true;
        }
    }
}


bool ACR_Compute (uint8_t port)
{
    pass = true; 
    
    // Zero out storage buffer
    for(uint16_t i = 0; i < CYCLES; i++)
    {
        for(uint16_t j = 0; j < SAMPLES; j++)
        {
            ADC_Buff.INJ[i][j] = 0;
            ADC_Buff.BATTV[i][j] = 0;
        }
    }
    
    // Create sine wave buffer for DAC
    sine_wave_table_init();
    
    // Collect Battery Injection Current and Voltage
    ACR_CollectData(port);
    
    // Process Real and Imaginary values
    ACR_ProcessData();
    
    if (pass == false)
    {
        return false;
        // ToDo figure out what makes a fail
    }
    return true;
}

void ACR_CollectData(uint8_t battery)
{   
    _LATB2 = 1; //B2 output pin hi TEST_EN - Turns on hardware to battery
    
    // Collect the injection current
    sample_cnt = 0;
    cycle_cnt = 0;
    
    // Clearing Channel_AN0 interrupt flag.
    IFS5bits.ADCAN0IF = 0;
    //TRGSRC0 SCCP2 Trigger
    ADTRIG0Lbits.TRGSRC0 = 0xD;
    
    // Turn off other channel trigger source
    ADTRIG4Lbits.TRGSRC16 = 0x0;
    ADTRIG1Lbits.TRGSRC4 = 0x0;
    
    collect_complete = false;
    
    CMP2_DACDataWrite(sine_wave[0]);
    
    // Initialize timer that runs ADC
    // Do not need to set counter value to zero, turning it off clears the counter
    SCCP2_Timer_Start();
    
    while(collect_complete == false);
    
    // Collect the battery voltage
    SCCP2_Timer_Stop();
    sample_cnt = 0;
    cycle_cnt = 0;
    ADTRIG0Lbits.TRGSRC0 = 0x0;

    if (battery == 1)
    // Clearing Channel_AN16 interrupt flag.
    IFS6bits.ADCAN16IF = 0;
    //TRGSRC16 SCCP2 Trigger
    ADTRIG4Lbits.TRGSRC16 = 0xD;
    
    if (battery == 2)
    // Clearing Channel_AN4 interrupt flag.
    IFS5bits.ADCAN4IF = 0;
    //TRGSRC4 SCCP2 Trigger
    ADTRIG1Lbits.TRGSRC4 = 0xD;
        
    collect_complete = false;

    CMP2_DACDataWrite(sine_wave[0]);
    
    // Initialize timer that runs ADC
    // Do not need to set counter value to zero, turning it off clears the counter
    SCCP2_Timer_Start();
    
    while(collect_complete == false);  

    SCCP2_Timer_Stop();
    
    _LATB2 = 0; //B2 output pin lo TEST_EN - Turns off hardware to battery    
    
}

//ADC channel 0 interrupt - Injection current on SINE_ADC
void __attribute__ ( ( __interrupt__ , auto_psv, weak ) ) _ADCAN0Interrupt ( void )
{
    RED_RB4_Toggle();
    ADC_Buff.INJ[cycle_cnt][sample_cnt] = ADCBUF0;

    sample_cnt++;
    CMP2_DACDataWrite(sine_wave[sample_cnt]);

    if (sample_cnt == SAMPLES)
    {
        sample_cnt = 0;
        cycle_cnt++;
    }
    if (cycle_cnt == CYCLES)
    {
        collect_complete = true;
    }

    //clear the Channel_AN0 interrupt flag
    IFS5bits.ADCAN0IF = 0;
    RED_RB4_Toggle();
}

// ADC channel 16 interrupt - Battery voltage on BAT_SNS_ADC
void __attribute__ ( ( __interrupt__ , auto_psv, weak ) ) _ADCAN16Interrupt ( void )
{
    GREEN_RB5_Toggle();
    ADC_Buff.BATTV[cycle_cnt][sample_cnt] = ADCBUF16; 

    sample_cnt++;
    CMP2_DACDataWrite(sine_wave[sample_cnt]);

    if (sample_cnt == SAMPLES)
    {
        sample_cnt = 0;
        cycle_cnt++;
    }
    if (cycle_cnt == CYCLES)
    {
        collect_complete = true;
    }

    //clear the Channel_AN16 interrupt flag
    IFS6bits.ADCAN16IF = 0;
    GREEN_RB5_Toggle();
}

/*******************************************************************************
 End of File
 */
